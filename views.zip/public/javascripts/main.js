var app = angular.module('toDOApp',[]);

app.controller('ToDOCtrl',['$scope',function($scope){
	$scope.todoRecs = ['a','b','v'];

	$scope.toDoSubmit = function(){
		$scope.todoRecs.push($scope.toDoText);
		$scope.toDoText = '';
	};

	$scope.todoClick = function(index){
		$scope.selectedIndex = index;
	};

}]);